#include <stdlib.h>
#include <string.h>
#include "hp165x.h"
#include "screensize.h"

#define INITIAL_MARGIN 8

_WRAP_1(drawText,0xeaf6);
_WRAP_1(setTextMode,0xeb08);
_WRAP_2(setCoordinates,0xeae4);

uint16_t screenHeight = DEFAULT_SCREEN_HEIGHT;
uint16_t screenWidth = SCREEN_WIDTH;

uint16_t getScreenHeight() {
	return screenHeight;
}

uint16_t getScreenWidth() {
	return screenWidth;
}

void drawBlack(void) {
	*SCREEN_MEMORY_CONTROL = WRITE_BLACK;
}

void drawWhite(void) {
	*SCREEN_MEMORY_CONTROL = WRITE_WHITE;
}

//_WRAP_0(initialScreen,0xeb02);

void initialScreen() {
	*SCREEN_MEMORY_CONTROL = WRITE_WHITE;
	fillScreen();

	volatile uint32_t* pos;
	volatile uint32_t* pos2;

	*SCREEN_MEMORY_CONTROL = WRITE_GRAY;
	pos = (uint32_t*)SCREEN;
	pos2 = pos + (ROM_SCREEN_HEIGHT-INITIAL_MARGIN) * (ROM_SCREEN_WIDTH/8);
	for (int16_t i = (ROM_SCREEN_WIDTH/8) * INITIAL_MARGIN ; i >= 0 ; i--) {
		*pos2++ = *pos++ = 0x000F000F;
	}
	pos = (uint32_t*)SCREEN + INITIAL_MARGIN * (ROM_SCREEN_WIDTH/8);
	pos2 = pos + (ROM_SCREEN_WIDTH/8) - 1;
	for (int16_t y = ROM_SCREEN_HEIGHT - 2 * INITIAL_MARGIN ; y >= 0 ; y--) {
		*pos = 0x000F000F;
		*pos2 = 0x000F000F;
		pos += ROM_SCREEN_WIDTH/8;
		pos2 += ROM_SCREEN_WIDTH/8;
	}
}

// TODO: readPixelAllPlanes()
void drawPixelAllPlanes(uint16_t x, uint16_t y, uint8_t value) {
	volatile uint16_t* pos = SCREEN + y * (SCREEN_WIDTH/4) + x/4;
	uint16_t v = 8>>(x%4);
	for (uint8_t mask=1; mask<0x10; mask<<=1) {
		if (mask & value)
			*SCREEN_MEMORY_CONTROL = SCREEN_MEMORY_CONTROL_VALUE(mask,mask);
		else
			*SCREEN_MEMORY_CONTROL = SCREEN_MEMORY_CONTROL_VALUE(~mask,mask);
		*pos = v;
	}
}

// fills screen
//  Because SCREEN_WIDTH/2 * screenHeight may not be divisible
//  by the 48 bytes we move in each step of the loop, the algorithm
//  can go over the top of the video memory a little. But the video memory
//  is mirrored at 0x620000, so if we use that, all will be well---we'll just
//  wipe a few bytes of invisible space.

void fillScreen(void) {
asm(
	"  move.l #0x620000, %%a1\n"
	"  move.l %%a1, %%a0\n"
	"  move.w screenHeight, %%d0\n"
	"  mulu.w #(" _QUOTE(SCREEN_WIDTH/2) "), %%d0\n" 
	"  add.l  %%d0, %%a0\n"
	"  move.l #0x000F000F, %%d0\n"
    "  move.l %%d0,%%d1\n"
    "  move.l %%d0,%%d2\n"
    "  move.l %%d0,%%d3\n"
    "  move.l %%d0,%%d4\n"
    "  move.l %%d0,%%d5\n"
    "  move.l %%d0,%%d6\n"
    "  move.l %%d0,%%d7\n"
    "  move.l %%d0,%%a2\n"
    "  move.l %%d0,%%a3\n"
    "  move.l %%d0,%%a4\n"
    "  move.l %%d0,%%a5\n"
	"1:\n"
	"  movem.l %%d0-%%d7/%%a2-%%a5,-(%%a0)\n" // ; clear 12 dwords at once, decrementing A0 by 48
    "  cmp.l %%a1,%%a0\n"
    "  bge 1b\n" : : : "d2", "d3", "d4", "d5", "d6", "d7", "a2", "a3", "a4", "a5" ); 
}

/* draws a frame around a fillRectangle() */
void frameRectangle(uint16_t topLeftX, uint16_t topLeftY, uint16_t bottomRightX, uint16_t bottomRightY, uint16_t thickness){
	int16_t left = topLeftX - thickness;
	if (left < 0)
		left = 0;
	int16_t top = topLeftY - thickness;
	if (top < 0)
		top = 0;
	int16_t right = bottomRightX + thickness;
	if (right > SCREEN_WIDTH)
		right = SCREEN_WIDTH;
	int16_t bottom = bottomRightY + thickness;
	if (bottom > screenHeight)
		bottom = screenHeight;
	fillRectangle(left,top,topLeftX,bottom);
	fillRectangle(bottomRightX,top,right,bottom);
	fillRectangle(topLeftX,top,bottomRightX,topLeftY);
	fillRectangle(topLeftX,bottomRightY,bottomRightX,bottom);
}

/* does not include bottomRight coordinate in rectangle */
void fillRectangle(uint16_t topLeftX, uint16_t topLeftY, uint16_t bottomRightX, uint16_t bottomRightY) {
	if (bottomRightY <= topLeftY || bottomRightX <= topLeftX)
		return;

	uint16_t height = bottomRightY - topLeftY;

	if (topLeftX == 0 && bottomRightX == SCREEN_WIDTH) {
		/* case 0: full rows */

		/* case 0a: full screen */
		if (topLeftX == 0 && bottomRightY == screenHeight) {
			/* use optimized assembly code */
			fillScreen();
			return;
		}

		/* case 0b: partial screen */
		volatile uint32_t* pos = (volatile uint32_t*)(SCREEN + topLeftY * SCREEN_WIDTH_WORDS);
		uint16_t n = SCREEN_WIDTH_DWORDS * height;
		while (n--)
			*pos++ = 0xF000F;
		return;
	}

	uint16_t width = bottomRightX - topLeftX;
	if (width == 0)
		return;


	uint16_t start_4 = topLeftX / 4;
	volatile uint16_t* pos = SCREEN + topLeftY * SCREEN_WIDTH_WORDS + start_4;	
	uint16_t end_4 = (bottomRightX - 1) / 4 - start_4;
	uint8_t startMod4 = topLeftX % 4;
	uint8_t endMod4 = (bottomRightX-1) % 4;
	
	if (end_4 == 0) {
		/* case 1: single 4 bit column */
		uint16_t writeMask = ((16>>startMod4)-1)-((8>>endMod4)-1);
		for (uint16_t i = 0 ; i < height ; i++) {
			*pos = writeMask;
			pos += SCREEN_WIDTH_WORDS;
		}
	}
	else if (end_4 == 1) {
		/* case 2: two 4 bit columns */
		uint32_t writeMask = (uint32_t)((16>>startMod4)-1) << 16 | (15-((8>>endMod4)-1));
		volatile uint32_t* pos2 = (volatile uint32_t*)pos;
		for (uint16_t i = 0 ; i < height ; i++) {
			*pos2 = writeMask;
			pos2 += SCREEN_WIDTH_DWORDS;
		}
	}
	else {
		/* case 3: more than two 4 bit columns */
		uint32_t writeMask = (uint32_t)((16>>startMod4)-1) << 16 | 0xF;
		volatile uint32_t* pos2 = (volatile uint32_t*)pos;
		for (uint16_t i = 0 ; i < height ; i++) {
			*pos2 = writeMask;
			pos2 += SCREEN_WIDTH_DWORDS;
		}
		pos += 2;
		width -= (4-startMod4)+4;
		while (width >= 8) {
			volatile uint32_t* pos2 = (volatile uint32_t*)pos;
			for (uint16_t i = 0 ; i < height ; i++) {
				*pos2 = 0xF000F;
				pos2 += SCREEN_WIDTH_DWORDS;
			}
			pos += 2;
			width -= 8;
		}
		if (width > 4) {
			volatile uint32_t* pos2 = (volatile uint32_t*)pos;			
			writeMask = 0xF0000 | (15-((8>>endMod4)-1));
			for (uint16_t i = 0 ; i < height ; i++) {
				*pos2 = writeMask;
				pos2 += SCREEN_WIDTH_DWORDS;
			}
		}
		else if (width > 0) {
			uint16_t endMask = 15-((8>>endMod4)-1);
			for (uint16_t i = 0 ; i < height ; i++) {
				*pos = endMask;
				pos += SCREEN_WIDTH_WORDS;
			}
		}
	}	
}

static uint8_t defaultLookupTable[16] = 
{
	0,2,1,1,0,
	0,2,2,2,0,
	0,0,2,2,0,0 
};

/* 
If you use this, be careful not to damage the
screen, as it can also change the mapping outside
the visible area and cause distortion. Also reset
on exit. 
*/

void setScreenLookupTable(uint8_t* table) {
/*  Write 1 to bit 7 of 202001.w
 Write the 16 entries to 204001.b, 204003.b, etc.
 Write 0 to bit 7 of 202000.w
 Keep 1 in bit 6.
*/	
	if (table == NULL)
		table = defaultLookupTable;
	*(volatile uint8_t*)0x202001 = 0x80;
	volatile uint8_t* p = (volatile uint8_t*)0x204001;
	for (uint16_t i=0; i<16; i++) {
		*p = table[i];
		p += 2;
	}
	*(volatile uint8_t*)0x202001 = 0x40;		
}

void initScreen(uint16_t height, uint16_t background) {
	_setScreenWidth();
	setScreenHeight(height);
	*SCREEN_MEMORY_CONTROL = background;
	fillScreen();
	setTextWindow(0,0,0,0);
	setTextColors((background==WRITE_WHITE) ? WRITE_BLACK : WRITE_WHITE, background);
	setTextXY(0,0);
	setTextReverse(0);
}
