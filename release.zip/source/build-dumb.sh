gcc -o d common/*.c dumb/*.c blorb/*.c -Icommon
