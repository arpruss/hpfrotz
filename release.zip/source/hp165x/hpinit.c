/*
 * dinit.c - HP165X interface, initialization
 *
 * This file is part of Frotz.
 *
 * Frotz is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Frotz is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 * Or visit http://www.fsf.org/
 */

#include <hp165x.h>
#include <hpposix.h>
#include <stdarg.h>

#include "hpfrotz.h"

extern f_setup_t f_setup;
extern z_header_t z_header;

static char* storyExts[] = {
	".dat",
	".z1",
	".z2",
	".z3",
	".z4",
	".z5",
	".z6",
	".z7",
	".z8",
	".qzl"
};


static int user_random_seed = -1;

bool quiet_mode;
static uint16_t tickRate = 60;

long int timeTenths() {
	return getVBLCounter()*10/ticksPerSecond();
}

struct chunkHeader {
	uint32_t chunkType;
	uint32_t size; // big endian, like HP
};

static bool findStoryForHeader(char* story, const struct IFhd* header) {
	DirEntry_t d;
	char buffer[0x20];
	
	uint16_t i = 0;
	while (-1 != getDirEntry(i, &d)) {
		if (right_type(&d, storyExts, sizeof storyExts / sizeof *storyExts)) {
			//hpPosixSetBufferedReadMaximum(0);
			FILE* f = fopen(d.name, "rb");
			//hpPosixSetBufferedReadMaximum(DEFAULT_BUFFERED_READ_MAXIMUM);
			if (f != NULL) {
				int32_t n = fread(buffer, 1, 0x20, f);
				fclose(f);
				if (n == 0x20 && *(uint16_t*)(buffer+2) == header->release &&
					*(uint16_t*)(buffer+0x1c) == header->checksum &&
					!memcmp(buffer+0x12, header->serial, 6)) {
						strcpy(story, d.name);
						return 1;
				}
			}
		}
		i++;
	}
	return 0;
}

struct IFhd* getSaveHeader(const char* save) {
	struct chunkHeader ch;
	
	static union {
		uint32_t h[3];
		struct IFhd IFhd;
	} header;

	FILE* f = fopen(save, "rb");
	if (f == NULL)
		return NULL;
	
	if (sizeof(header.h) != fread(header.h,1,sizeof(header.h),f)) {
		fclose(f);
		return NULL;
	}
	
	if (header.h[0] != 'FORM' || header.h[2] != 'IFZS') {
		fclose(f);
		return NULL;
	}
	
	while(1) {
		if (sizeof(ch) != fread(&ch, 1, sizeof(ch), f)) {
			fclose(f);
			return NULL;
		}
		if (ch.chunkType == 'IFhd') {
			if (sizeof(struct IFhd) != fread(&header.IFhd,1,sizeof(struct IFhd),f)) {
				fclose(f);
				return NULL;
			}
			fclose(f);
			return &header.IFhd;
		}
		else {
			if (0 != fseek(f, ch.size, SEEK_CUR)) {
				fclose(f);
				return NULL;
			}				
		}
	}
}

static bool findStoryForSave(char* story, const char* save) {
	struct IFhd* h = getSaveHeader(save);
	if (h == NULL)
		return false;
	return findStoryForHeader(story, h);
}

/*
 * os_process_arguments
 *
 * Handle command line switches.
 * Some variables may be set to activate special features of Frotz.
 *
 */
void os_process_arguments(int _argc, char *_argv[])
{
	char *p = NULL;
	
	static char story[MAX_FILE_NAME+1];
	static char save[MAX_FILE_NAME+1];
	hp_set_window();
	if (!pick_file(story,storyExts,sizeof(storyExts)/sizeof(*storyExts),-1)) {
		hp_clear_window();
		putText("Goodbye!\n");
		os_quit(0);
	}
	hp_clear_window();
	
	short n = strlen(story);
	short e = strlen(EXT_SAVE);
	if (n >= e && 0==strcasecmp(story+n-e, EXT_SAVE)) {
		strcpy(save, story);
		if (!findStoryForSave(story, save)) {
			putText("Cannot find matching story file.\n");
			os_quit(2);
		}
		f_setup.restore_mode = 1;
	}
	else {
		f_setup.restore_mode = 0;
	}
		
	quiet_mode = FALSE;

	f_setup.format = FORMAT_NORMAL;

	/* Save the story file name */
	f_setup.story_file = strdup(story);

	f_setup.story_name = strdup(f_setup.story_file);

	if (!quiet_mode) {
		printf("Loading %s.\n", f_setup.story_file);

	}

	/* Now strip off the extension */
	p = strrchr(f_setup.story_name, '.');
	if ( p != NULL )
		*p = '\0';	/* extension removed */

#ifndef NO_SCRIPT
	/* Create nice default file names */
	f_setup.script_name = malloc((strlen(f_setup.story_name) + strlen(EXT_SCRIPT) + 1) * sizeof(char));
	memcpy(f_setup.script_name, f_setup.story_name, (strlen(f_setup.story_name) + strlen(EXT_SCRIPT)) * sizeof(char));
	strncat(f_setup.script_name, EXT_SCRIPT, strlen(EXT_SCRIPT)+1);

	f_setup.command_name = malloc((strlen(f_setup.story_name) + strlen(EXT_COMMAND) + 1) * sizeof(char));
	memcpy(f_setup.command_name, f_setup.story_name, (strlen(f_setup.story_name) + strlen(EXT_COMMAND)) * sizeof(char));
	strncat(f_setup.command_name, EXT_COMMAND, strlen(EXT_COMMAND)+1);
#endif	

	if (!f_setup.restore_mode) {
		f_setup.save_name = malloc((strlen(f_setup.story_name) + strlen(EXT_SAVE) + 1) * sizeof(char));
		memcpy(f_setup.save_name, f_setup.story_name, (strlen(f_setup.story_name) + strlen(EXT_SAVE)) * sizeof(char));
		strncat(f_setup.save_name, EXT_SAVE, strlen(EXT_SAVE) + 1);
	} else { /* Set our auto load save as the name save */
		f_setup.save_name = strdup(save);
	}

	f_setup.aux_name = malloc((strlen(f_setup.story_name) + strlen(EXT_AUX) + 1) * sizeof(char));
	memcpy(f_setup.aux_name, f_setup.story_name, (strlen(f_setup.story_name) + strlen(EXT_AUX)) * sizeof(char));
	strncat(f_setup.aux_name, EXT_AUX, strlen(EXT_AUX) + 1);
} /* os_process_arguments */


void os_init_screen(void)
{
	if (z_header.version == V3 && f_setup.tandy)
		z_header.config |= CONFIG_TANDY;

	if (z_header.version >= V5 && f_setup.undo_slots == 0)
		z_header.flags &= ~UNDO_FLAG;

	z_header.screen_rows = getTextRows();
	z_header.screen_cols = getTextColumns();

	/* Use the ms-dos interpreter number for v6, because that's the
	 * kind of graphics files we understand.  Otherwise, use DEC.  */
	if (f_setup.interpreter_number == INTERP_DEFAULT)
		z_header.interpreter_number = z_header.version ==
			6 ? INTERP_MSDOS : INTERP_DEC_20;
	else
		z_header.interpreter_number = f_setup.interpreter_number;

	z_header.interpreter_version = 'F';

	hp_init_input();
	hp_init_output();
} /* os_init_screen */


int os_random_seed (void)
{
	if (user_random_seed == -1)	/* Use the epoch as seed value */
		return (timeTenths() & 0x7fff);
	return user_random_seed;
} /* os_random_seed */


/*
 * os_quit
 *
 * Immediately and cleanly exit, passing along exit status.
 *
 */
void os_quit(int status)
{
	if (status)
		waitSeconds(4);
	reload();
} /* os_quit */


void os_restart_game (int UNUSED (stage)) {}


/*
 * os_warn
 *
 * Display a warning message and continue with the game.
 *
 */
void os_warn (const char *s, ...)
{
	va_list m;
	int style;

	os_beep(BEEP_HIGH);
	style = os_get_text_style();
	os_set_text_style(BOLDFACE_STYLE);
	fprintf(stderr, "Warning: ");
	os_set_text_style(NORMAL_STYLE);
	va_start(m, s);
	vfprintf(stderr, s, m);
	va_end(m);
	fprintf(stderr, "\n");
	os_set_text_style(style);
	return;
} /* os_warn */


/*
 * os_fatal
 *
 * Display error message and exit program.
 *
 */
void os_fatal (const char *s, ...)
{
	fprintf(stderr, "\nFatal error: %s\n", s);
	if (f_setup.ignore_errors)
		fprintf(stderr, "Continuing anyway...\n");
	else
		os_quit(EXIT_FAILURE);
} /* os_fatal */


FILE *os_load_story(void)
{
	/* this is a large file, so don't buffer it all into memory;
		instead, open and reopen it as needed */
	//hpPosixSetBufferedReadMaximum(100000);
	FILE* f = fopen(f_setup.story_file, "rb");
	return f;
} /* os_load_story */


/*
 * Seek into a storyfile, either a standalone file or the
 * ZCODE chunk of a blorb file.
 */
int os_storyfile_seek(FILE * fp, long offset, int whence)
{
	return fseek(fp, offset, whence);
} /* os_storyfile_seek */


/*
 * Tell the position in a storyfile, either a standalone file
 * or the ZCODE chunk of a blorb file.
 */
int os_storyfile_tell(FILE * fp)
{
	return ftell(fp);
} /* os_storyfile_tell */

static void intro(void)
{
	printf("FROTZ V%s - HP165x interface.\n", VERSION);
	printf("Notes:          %s\n", RELEASE_NOTES);
	printf("  Frotz was originally written by Stefan Jokisch.\n");
	printf("  It complies with standard 1.1 of the Z-Machine Standard.\n");
	printf("  It was ported to Unix by Galen Hazelwood.\n");
	printf("  It is distributed under the GNU General Public License version 2 or\n");
	printf("    (at your option) any later version.\n");
	printf("  This software is offered as-is with no warranty or liability.\n");
	printf("  The HP 1652B/1653B port is maintained by Alexander Pruss.\n");
	printf("  Frotz's homepage is https://661.org/proj/if/frotz.\n\n");
} /* usage */


void os_init_setup(void)
{
	initScreen(392, BACKGROUND); 
	tickRate = ticksPerSecond();
	initKeyboard(1);
	intro();
} /* os_init_setup */


