def decodePart(glyph, rows):
    for i in range(rows):
        l = ""
        for j in range(8):
            if (ord(glyph[j]) - 0x3F) & 1<<i:
                l += "#"
            else:
                l += "."
        print(l)

def decode(glyph):
    print("........")
    print("........")
    decodePart(glyph, 6)
    decodePart(glyph[9:], 4)
    print("........")
    print("........")

with open("font3.dat", "r") as f:
    for line in f:
        line = line.strip()
        if line.startswith("<PRINC "):
            glyph = line[8:26]
            name = line[31:]
            print(name)
            decode(glyph)